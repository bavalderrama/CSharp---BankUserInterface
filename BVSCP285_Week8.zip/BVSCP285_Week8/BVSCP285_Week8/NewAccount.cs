﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;
using System.Xml.Linq;

namespace BVSCP285_Week8
{
    public partial class NewAccount : Form
    {
        string acctNumber { get; set; }
        string LName { get; set; }
        string Balance { get; set; }
        decimal BalanceD { get; set; }

        int bAO;
        public NewAccount()
        {
            InitializeComponent();
        }
        private void buttonS_Click(object sender, EventArgs e)
        {      
            if (string.IsNullOrWhiteSpace(textBoxAN.Text) || string.IsNullOrWhiteSpace(textBoxLN.Text) || string.IsNullOrWhiteSpace(textBoxB.Text))
            {
                MessageBox.Show("Please fill out all fields");
            }
            else
            {
                acctNumber = textBoxAN.Text;
                LName = textBoxLN.Text;
                Balance = textBoxB.Text;
                BalanceD = decimal.Parse(Balance);
                Main.bAO++;
                Main.addNewBankAccount(acctNumber, LName, BalanceD);
                this.Close();
            }
        }
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

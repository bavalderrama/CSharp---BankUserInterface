﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BVSCP285_Week8
{
    public class BankAccount
    {
        public string AcctNumber { get; set; }
        public string LName { get; set; }
        public decimal Balance { get; set; }

        public BankAccount() : this(string.Empty, string.Empty, 0M) { }

        public BankAccount(string _AcctNumber, string _LName, decimal _Balance)
        {  
            AcctNumber = _AcctNumber;
            LName = _LName;
            Balance = _Balance;
        }
        public string toString() 
        {
            return $"Account Number: {AcctNumber}\t Last Name: {LName}\t Balance: {Balance:C}";
        }
    }
}

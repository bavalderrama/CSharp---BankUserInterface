﻿namespace BVSCP285_Week8
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxLN = new TextBox();
            textBoxB = new TextBox();
            buttonUF = new Button();
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            selectDataFileToolStripMenuItem = new ToolStripMenuItem();
            newDataFileToolStripMenuItem = new ToolStripMenuItem();
            newAccountToolStripMenuItem = new ToolStripMenuItem();
            displayAccountsToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            comboBox1 = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // textBoxLN
            // 
            textBoxLN.Location = new Point(216, 127);
            textBoxLN.Name = "textBoxLN";
            textBoxLN.Size = new Size(151, 27);
            textBoxLN.TabIndex = 0;
            textBoxLN.TextChanged += textBoxLN_TextChanged;
            // 
            // textBoxB
            // 
            textBoxB.Location = new Point(216, 204);
            textBoxB.Name = "textBoxB";
            textBoxB.Size = new Size(151, 27);
            textBoxB.TabIndex = 1;
            textBoxB.TextChanged += textBoxB_TextChanged;
            // 
            // buttonUF
            // 
            buttonUF.Enabled = false;
            buttonUF.Location = new Point(462, 116);
            buttonUF.Name = "buttonUF";
            buttonUF.Size = new Size(196, 48);
            buttonUF.TabIndex = 2;
            buttonUF.Text = "Update File";
            buttonUF.UseVisualStyleBackColor = true;
            buttonUF.Click += buttonUF_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(699, 28);
            menuStrip1.TabIndex = 3;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { selectDataFileToolStripMenuItem, newDataFileToolStripMenuItem, newAccountToolStripMenuItem, displayAccountsToolStripMenuItem, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(46, 24);
            fileToolStripMenuItem.Text = "File";
            // 
            // selectDataFileToolStripMenuItem
            // 
            selectDataFileToolStripMenuItem.Name = "selectDataFileToolStripMenuItem";
            selectDataFileToolStripMenuItem.Size = new Size(224, 26);
            selectDataFileToolStripMenuItem.Text = "Select Data File";
            selectDataFileToolStripMenuItem.Click += selectDataFileToolStripMenuItem_Click;
            // 
            // newDataFileToolStripMenuItem
            // 
            newDataFileToolStripMenuItem.Name = "newDataFileToolStripMenuItem";
            newDataFileToolStripMenuItem.Size = new Size(224, 26);
            newDataFileToolStripMenuItem.Text = "New Data File";
            newDataFileToolStripMenuItem.Click += newDataFileToolStripMenuItem_Click;
            // 
            // newAccountToolStripMenuItem
            // 
            newAccountToolStripMenuItem.Name = "newAccountToolStripMenuItem";
            newAccountToolStripMenuItem.Size = new Size(224, 26);
            newAccountToolStripMenuItem.Text = "New Account";
            newAccountToolStripMenuItem.Click += newAccountToolStripMenuItem_Click;
            // 
            // displayAccountsToolStripMenuItem
            // 
            displayAccountsToolStripMenuItem.Name = "displayAccountsToolStripMenuItem";
            displayAccountsToolStripMenuItem.Size = new Size(224, 26);
            displayAccountsToolStripMenuItem.Text = "Display Accounts";
            displayAccountsToolStripMenuItem.Click += displayAccountsToolStripMenuItem_Click;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(224, 26);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(216, 57);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 4;
            comboBox1.SelectedValueChanged += comboBox1_SelectedValueChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(72, 60);
            label1.Name = "label1";
            label1.Size = new Size(121, 20);
            label1.TabIndex = 5;
            label1.Text = "Account Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(72, 130);
            label2.Name = "label2";
            label2.Size = new Size(79, 20);
            label2.TabIndex = 6;
            label2.Text = "Last Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(72, 207);
            label3.Name = "label3";
            label3.Size = new Size(61, 20);
            label3.TabIndex = 7;
            label3.Text = "Balance";
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(699, 280);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(comboBox1);
            Controls.Add(buttonUF);
            Controls.Add(textBoxB);
            Controls.Add(textBoxLN);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Main";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Main";
            Shown += Form1_Shown;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxLN;
        private TextBox textBoxB;
        static private Button buttonUF;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem selectDataFileToolStripMenuItem;
        private ToolStripMenuItem newDataFileToolStripMenuItem;
        private ToolStripMenuItem newAccountToolStripMenuItem;
        private ToolStripMenuItem displayAccountsToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private Label label1;
        private Label label2;
        private Label label3;
        static public ComboBox comboBox1;
    }
}

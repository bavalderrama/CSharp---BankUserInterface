﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BVSCP285_Week8
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
        }
        public Report(BankAccount[] accounts) 
        {
            InitializeComponent();

            string[] modAcctNumber = new string[Main.bAO];
                        
            if ( Main.bAO != 0 )
            {
                listBox1.Items.Add($"Account No.\t Last Name \t Balance");
                for (int i = 0; i < Main.bAO; i++)
                {
                    modAcctNumber[i] = new string('*', accounts[i].AcctNumber.Length - 3) + accounts[i].AcctNumber.Substring(accounts[i].AcctNumber.Length - 3);
                    listBox1.Items.Add($"{modAcctNumber[i]}\t\t {accounts[i].LName}\t\t {accounts[i].Balance.ToString("C")}");
                }
            }
            else
            {
                MessageBox.Show("Please select a file or manually add at least one account first");
            }

        }
        private void buttonCAI_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            this.Close();
        }
    }
}

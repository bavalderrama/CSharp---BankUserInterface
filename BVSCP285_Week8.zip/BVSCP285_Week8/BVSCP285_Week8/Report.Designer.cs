﻿namespace BVSCP285_Week8
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonCAI = new Button();
            listBox1 = new ListBox();
            SuspendLayout();
            // 
            // buttonCAI
            // 
            buttonCAI.Location = new Point(337, 370);
            buttonCAI.Name = "buttonCAI";
            buttonCAI.Size = new Size(158, 41);
            buttonCAI.TabIndex = 1;
            buttonCAI.Text = "Close";
            buttonCAI.UseVisualStyleBackColor = true;
            buttonCAI.Click += buttonCAI_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(51, 32);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(695, 304);
            listBox1.TabIndex = 2;
            // 
            // AcctInfo
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listBox1);
            Controls.Add(buttonCAI);
            Name = "AcctInfo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Accounts Info";
            ResumeLayout(false);
        }

        #endregion
        private Button buttonCAI;
        private ListBox listBox1;
    }
}
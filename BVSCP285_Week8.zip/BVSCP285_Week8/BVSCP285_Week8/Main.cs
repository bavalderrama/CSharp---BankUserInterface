using Microsoft.VisualBasic.ApplicationServices;
using System.Diagnostics.Metrics;

namespace BVSCP285_Week8
{
    public partial class Main : Form
    {
        static private StreamReader fileReader;
        static public StreamWriter fileWriter;
        static public string fileName;
        private static int numberOfRecords = 12;
        protected string[] fields = new string[numberOfRecords];

        // ideally, an empty array would be initialized -> BankAccount[] bankAccounts = Array.Empty<BankAccount>();
        static protected BankAccount[] bankAccounts = new BankAccount[numberOfRecords];
        static public int bAO { get; set; } // bankAccountObject

        static protected bool archiveFlag = false;
        static protected bool loadingValues = false;
        public Main()
        {
            InitializeComponent();
        }
        private void Form1_Shown(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome!\nTo begin, select a data file or create a new data file using the File menu");
        }
        private void selectDataFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result;
            //string fileName;
            //var bankAccounts = new List<BankAccount>();

            using (OpenFileDialog fileChooser = new OpenFileDialog())
            {
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName;

                if (result == DialogResult.OK)
                {
                    if (string.IsNullOrEmpty(fileName))
                    {
                        MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        try
                        {
                            FileStream input = new FileStream(fileName, FileMode.Open, FileAccess.Read);

                            fileReader = new StreamReader(input);
                        }
                        catch (IOException)
                        {
                            MessageBox.Show("Error reading from file", "File Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }

            try
            {
                int lineCount = 0;
                string line;

                int counter = 0;

                while (!fileReader.EndOfStream)
                {
                    line = fileReader.ReadLine();
                    fields = line.Split(',');
                    bankAccounts[bAO] = new BankAccount(fields[counter], fields[counter + 1], decimal.Parse(fields[counter + 2]));
                    comboBox1.Items.Add(bankAccounts[bAO].AcctNumber);

                    counter = 0;
                    bAO++;
                }
            }
            catch (IOException)
            {
                MessageBox.Show("Error Reading from File - IO Exception", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("Error Reading from File - Index Out of Range Exception", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            loadingValues = true;
            archiveFlag = false;
            buttonUF.Enabled = false;
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (archiveFlag)
            {
                buttonUF.Enabled = true;
                MessageBox.Show("File values have changed. Please click 'Update File' to save changes.");
            }
            else
            {
                this.Close();
            }
            
        }
        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < comboBox1.Items.Count; i++)
            {
                if (comboBox1.Text == bankAccounts[i].AcctNumber)
                {
                    textBoxLN.Text = bankAccounts[i].LName;
                    textBoxB.Text = (bankAccounts[i].Balance).ToString("C");
                }
            }

            loadingValues = true;
            archiveFlag = false;
            buttonUF.Enabled = false;
        }
        private void textBoxLN_TextChanged(object sender, EventArgs e)
        {
            if (loadingValues)
            {
                archiveFlag = false;
                buttonUF.Enabled = false;
            }
            else
            {
                archiveFlag = true;
                buttonUF.Enabled = true;
            }

            for (int i = 0; i < comboBox1.Items.Count; i++)
            {
                if (textBoxLN.Text != bankAccounts[i].LName)
                {
                    loadingValues = false;
                    archiveFlag = true;
                    buttonUF.Enabled = true;
                }
                else
                {
                    loadingValues = true;
                    archiveFlag = false;
                    buttonUF.Enabled = false;
                }
            }
        }
        private void textBoxB_TextChanged(object sender, EventArgs e)
        {
            if (loadingValues)
            {
                archiveFlag = false;
                buttonUF.Enabled = false;
            }
            else
            {
                archiveFlag = true;
                buttonUF.Enabled = true;
            }

            for (int i = 0; i < comboBox1.Items.Count; i++)
            {
                if (textBoxB.Text != (bankAccounts[i].Balance).ToString())
                {
                    loadingValues = false;
                    archiveFlag = true;
                    buttonUF.Enabled = true;
                }
                else
                {
                    loadingValues = true;
                    archiveFlag = false;
                    buttonUF.Enabled = false;
                }
            }
        }
        private void displayAccountsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Report acctInfo = new Report(bankAccounts);
            acctInfo.ShowDialog();
        }
        private void newAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewAccount newAccount = new NewAccount();
            newAccount.ShowDialog();
        }
        static public void addNewBankAccount(string _acctNumber, string _lName, decimal _balance)
        {
            bankAccounts[bAO - 1] = new BankAccount(_acctNumber, _lName, _balance);
            comboBox1.Items.Add(bankAccounts[bAO - 1].AcctNumber);
            buttonUF.Enabled = true;
            archiveFlag = true;
        }
        private void buttonUF_Click(object sender, EventArgs e)
        {
            saveToFile();
        }
        private void newDataFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClearValues();

            DialogResult result;

            using (var fileChooser = new SaveFileDialog())
            {
                fileChooser.CheckFileExists = false;
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName;
            }

            if (result == DialogResult.OK)
            {
                if (string.IsNullOrEmpty(fileName))
                {
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    try
                    {
                        fileName = Path.GetFileNameWithoutExtension(fileName);
                        var output = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write);
                        fileWriter = new StreamWriter(output);

                        for (int i = 0; i < bAO; i++)
                        {
                            // Must add logic here to capture modified value(s) currently in Text Box and save into bankAccounts array
                            fileWriter.WriteLine($"{bankAccounts[i].AcctNumber},{bankAccounts[i].LName},{(bankAccounts[i].Balance).ToString()}");
                        }
                        fileWriter.Close();

                        buttonUF.Enabled = false;
                        archiveFlag = false;
                        loadingValues = true;
                    }
                    catch (IOException)
                    {
                        MessageBox.Show("Error opening file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        public void ClearValues() 
        {
            foreach (Control guiControl in Controls) 
            {
                (guiControl as TextBox)?.Clear();                
            }

            comboBox1.Text = "";
            comboBox1.Items.Clear();
            comboBox1.SelectedIndex = -1;

            Array.Clear(bankAccounts, 0, bankAccounts.Length);
            bAO = 0;
        }
        public void saveToFile() 
        {
            DialogResult result;

            if (string.IsNullOrEmpty(fileName))
            {
                MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    fileName = Path.GetFileNameWithoutExtension(fileName);
                    var output = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write);
                    fileWriter = new StreamWriter(output);

                    for (int i = 0; i < bAO; i++)
                    {
                        // Must add logic here to capture modified value(s) currently in Text Box and save into bankAccounts array
                        fileWriter.WriteLine($"{bankAccounts[i].AcctNumber},{bankAccounts[i].LName},{(bankAccounts[i].Balance).ToString()}");
                    }
                    fileWriter.Close();
                    MessageBox.Show("The file has been updated!");

                    buttonUF.Enabled = false;
                    archiveFlag = false;
                    loadingValues = true;
                        
            }
                catch (IOException)
                {
                    MessageBox.Show("Error opening file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            
        }

    }
}
